-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: bloom_app
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `farming_activities`
--

DROP TABLE IF EXISTS `farming_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `farming_activities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `farmer_id` int NOT NULL,
  `crop_id` int NOT NULL,
  `activity_type` enum('planting','fertilizing','irrigation','weeding','pest_control','harvesting','pruning','soil_testing') NOT NULL,
  `activity_date` date NOT NULL,
  `description` text,
  `cost` decimal(10,2) DEFAULT '0.00',
  `quantity_used` decimal(10,2) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('scheduled','completed') DEFAULT 'scheduled',
  PRIMARY KEY (`id`),
  KEY `farmer_id` (`farmer_id`),
  KEY `crop_id` (`crop_id`),
  CONSTRAINT `farming_activities_ibfk_1` FOREIGN KEY (`farmer_id`) REFERENCES `farmers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `farming_activities_ibfk_2` FOREIGN KEY (`crop_id`) REFERENCES `farmer_crops` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `farming_activities`
--

LOCK TABLES `farming_activities` WRITE;
/*!40000 ALTER TABLE `farming_activities` DISABLE KEYS */;
INSERT INTO `farming_activities` VALUES (1,1,1,'planting','2024-01-15','Initial planting with fertilizer application',1200.00,25.00,'kg',NULL,'2025-11-01 23:10:20','scheduled'),(2,1,1,'fertilizing','2024-02-10','Top dressing with urea',800.00,50.00,'kg',NULL,'2025-11-01 23:10:20','scheduled'),(3,1,2,'planting','2024-02-01','Sorghum planting with seed treatment',950.00,8.00,'kg',NULL,'2025-11-01 23:10:20','scheduled'),(4,1,3,'irrigation','2024-02-05','Weekly irrigation cycle',150.00,0.00,'hours',NULL,'2025-11-01 23:10:20','scheduled'),(5,1,1,'pest_control','2024-02-20','Armyworm control spraying',450.00,5.00,'liters',NULL,'2025-11-01 23:10:20','scheduled'),(6,1,5,'planting','2024-01-30','Watermelon seedling transplant',680.00,500.00,'plants',NULL,'2025-11-01 23:10:20','scheduled'),(7,1,4,'planting','2024-02-10','Groundnut planting with rhizobium',420.00,35.00,'kg',NULL,'2025-11-01 23:10:20','scheduled'),(8,1,1,'fertilizing','2025-11-04','Second top dressing',650.00,40.00,'kg',NULL,'2025-11-01 23:10:20','scheduled'),(9,1,3,'weeding','2025-11-03','Manual weeding',300.00,0.00,'hours',NULL,'2025-11-01 23:10:20','completed'),(10,1,5,'irrigation','2025-11-05','Fertigation application',280.00,3.00,'hours',NULL,'2025-11-01 23:10:20','scheduled'),(11,1,2,'pest_control','2025-11-07','Stemborer monitoring',520.00,4.00,'liters',NULL,'2025-11-01 23:10:20','scheduled'),(12,1,2,'weeding','2025-11-02','',40.00,NULL,NULL,NULL,'2025-11-02 10:32:36','completed');
/*!40000 ALTER TABLE `farming_activities` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-02 16:31:02
