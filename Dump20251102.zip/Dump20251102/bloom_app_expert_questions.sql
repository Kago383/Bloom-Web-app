-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: bloom_app
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `expert_questions`
--

DROP TABLE IF EXISTS `expert_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expert_questions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `farmer_id` int NOT NULL,
  `question` text NOT NULL,
  `answer` text,
  `category` varchar(100) DEFAULT NULL,
  `status` enum('pending','answered') DEFAULT 'answered',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `answered_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `farmer_id` (`farmer_id`),
  CONSTRAINT `expert_questions_ibfk_1` FOREIGN KEY (`farmer_id`) REFERENCES `farmers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expert_questions`
--

LOCK TABLES `expert_questions` WRITE;
/*!40000 ALTER TABLE `expert_questions` DISABLE KEYS */;
INSERT INTO `expert_questions` VALUES (1,1,'Why are my crop leaves turning yellow?','Thank you for your question about farming practices. For detailed, specific advice, consider contacting your local agricultural extension officer who can provide personalized guidance based on your specific conditions and location. Remember to always follow recommended practices for your region and crop variety.','general','answered','2025-11-02 11:05:44','2025-11-02 11:05:44'),(2,1,'What spacing should I use for planting beans?','For planting: Use certified seeds, plant at recommended depths (2-5cm depending on crop), ensure proper spacing (maize: 75cm between rows, 25cm within rows), and plant at the onset of rains for optimal germination.','planting','answered','2025-11-02 11:06:19','2025-11-02 11:06:19'),(3,1,'How do I control Fall Armyworm in my maize field?','For Fall Armyworm control: Use recommended insecticides like Emamectin benzoate or Spinosad. Apply early in the morning or late afternoon. Remove and destroy infected plants. Practice crop rotation to break the pest cycle.','pest_control','answered','2025-11-02 11:09:38','2025-11-02 11:09:38'),(4,1,'How do I know when maize is ready for harvest?','For harvesting: Harvest at physiological maturity. For maize, harvest when kernels are hard and moisture content is 20-25%. Use clean equipment, dry properly to 13% moisture, and store in clean, pest-free conditions.','harvesting','answered','2025-11-02 11:10:26','2025-11-02 11:10:26');
/*!40000 ALTER TABLE `expert_questions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-02 16:31:02
